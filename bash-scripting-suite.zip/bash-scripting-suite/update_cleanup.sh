#!/usr/bin/env bash
set -euo pipefail
LOGFILE="${LOGFILE:-/var/log/maint_suite/update_cleanup.log}"
mkdir -p "$(dirname "$LOGFILE")"
echo "[$(date +%F %T)] Starting system update & cleanup" | tee -a "$LOGFILE"
if command -v apt-get >/dev/null 2>&1; then
  echo "Detected apt-based system" | tee -a "$LOGFILE"
  apt-get update | tee -a "$LOGFILE"
  DEBIAN_FRONTEND=noninteractive apt-get -y upgrade | tee -a "$LOGFILE"
  apt-get -y autoremove --purge | tee -a "$LOGFILE"
  apt-get -y autoclean | tee -a "$LOGFILE"
elif command -v dnf >/dev/null 2>&1; then
  echo "Detected dnf-based system" | tee -a "$LOGFILE"
  dnf -y upgrade --refresh | tee -a "$LOGFILE"
  dnf -y autoremove | tee -a "$LOGFILE"
  dnf -y clean all | tee -a "$LOGFILE"
elif command -v yum >/dev/null 2>&1; then
  echo "Detected yum-based system" | tee -a "$LOGFILE"
  yum -y update | tee -a "$LOGFILE"
  yum -y autoremove || true
  yum -y clean all
else
  echo "No supported package manager found (apt/dnf/yum)" | tee -a "$LOGFILE"
  exit 2
fi
echo "[$(date +%F %T)] Update & cleanup finished" | tee -a "$LOGFILE"
exit 0
