#!/usr/bin/env bash
set -euo pipefail
SCRIPTDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOGDIR="/var/log/maint_suite"
sudo mkdir -p "$LOGDIR"
sudo chown "$(id -u):$(id -g)" "$LOGDIR" || true
sudo chmod 755 "$LOGDIR"
if [[ ! -d /opt/maint_suite ]]; then
  sudo mkdir -p /opt/maint_suite
  sudo cp -r "$SCRIPTDIR"/* /opt/maint_suite/
  sudo chmod +x /opt/maint_suite/*.sh
fi
echo "Installation done. Scripts available at /opt/maint_suite"
echo "Example: sudo /opt/maint_suite/maintenance_menu.sh"
