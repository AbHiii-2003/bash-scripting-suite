#!/usr/bin/env bash
SCRIPTDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOGDIR="/var/log/maint_suite"
mkdir -p "$LOGDIR"
while true; do
  clear
  cat <<EOF
===== System Maintenance Suite =====
1) Run Backup (backup.sh)
2) Run System Update & Cleanup (update_cleanup.sh)
3) Run Log Monitor (log_monitor.sh)
4) Collect Report Files (user_reports.sh)
5) Run all (backup -> update -> logmonitor -> reports)
6) Install crontab entries (will only show example)
7) Exit
Choose [1-7]:
EOF
  read -rp "> " choice
  case "$choice" in
    1) sudo "$SCRIPTDIR/backup.sh" /home ;;
    2) sudo "$SCRIPTDIR/update_cleanup.sh" ;;
    3) "$SCRIPTDIR/log_monitor.sh" ;;
    4) "$SCRIPTDIR/user_reports.sh" ;;
    5)
       sudo "$SCRIPTDIR/backup.sh" /home
       sudo "$SCRIPTDIR/update_cleanup.sh"
       "$SCRIPTDIR/log_monitor.sh"
       "$SCRIPTDIR/user_reports.sh"
       ;;
    6)
       echo "Sample cron entries:"
       echo "0 2 * * * /usr/bin/env bash $SCRIPTDIR/backup.sh /home >> /var/log/maint_suite/cron_backup.log 2>&1"
       echo "0 4 * * 0 /usr/bin/env bash $SCRIPTDIR/update_cleanup.sh >> /var/log/maint_suite/cron_update.log 2>&1"
       echo "*/30 * * * * /usr/bin/env bash $SCRIPTDIR/log_monitor.sh >> /var/log/maint_suite/cron_logmonitor.log 2>&1"
       read -rp "Do you want to append these to current user's crontab? [y/N]: " yn
       if [[ "$yn" =~ ^[Yy]$ ]]; then
         (crontab -l 2>/dev/null; echo "0 2 * * * /usr/bin/env bash $SCRIPTDIR/backup.sh /home >> /var/log/maint_suite/cron_backup.log 2>&1"; echo "0 4 * * 0 /usr/bin/env bash $SCRIPTDIR/update_cleanup.sh >> /var/log/maint_suite/cron_update.log 2>&1"; echo "*/30 * * * * /usr/bin/env bash $SCRIPTDIR/log_monitor.sh >> /var/log/maint_suite/cron_logmonitor.log 2>&1") | crontab -
         echo "Crontab updated."
       fi
       ;;
    7) exit 0 ;;
    *) echo "Invalid choice" ;;
  esac
  echo "Press Enter to continue..."
  read -r _
done
