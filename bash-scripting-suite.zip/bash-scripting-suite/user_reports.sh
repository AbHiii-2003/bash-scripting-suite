#!/usr/bin/env bash
OUTDIR="${OUTDIR:-./report_output}"
mkdir -p "$OUTDIR"
date > "$OUTDIR"/collected_at.txt
uname -a > "$OUTDIR"/uname.txt
lsb_release -a 2>/dev/null || true > "$OUTDIR"/distro.txt
free -h > "$OUTDIR"/mem.txt
df -h > "$OUTDIR"/df.txt
ps aux --sort=-%cpu | head -n 20 > "$OUTDIR"/top_processes.txt
echo "Collected system info to $OUTDIR"
