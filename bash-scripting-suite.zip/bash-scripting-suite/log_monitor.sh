#!/usr/bin/env bash
set -euo pipefail
LOG_DIR="${LOG_DIR:-/var/log}"
TARGET_LOGS=(/var/log/syslog /var/log/messages /var/log/auth.log)
ALERT_FILE="${ALERT_FILE:-/var/log/maint_suite/log_alerts.txt}"
PATTERNS=("error" "fail" "failed" "segfault" "panic" "unauthoriz" "denied")
SINCE_MINUTES="${SINCE_MINUTES:-60}"
mkdir -p "$(dirname "$ALERT_FILE")"
echo "[$(date +%F %T)] Log check started (last $SINCE_MINUTES min)" > "$ALERT_FILE"
if command -v journalctl >/dev/null 2>&1; then
  echo "Using journalctl for last $SINCE_MINUTES minutes" >> "$ALERT_FILE"
  journalctl --since "${SINCE_MINUTES} minutes ago" -p err..emerg --no-pager >> "$ALERT_FILE" || true
else
  for logf in "${TARGET_LOGS[@]}"; do
    if [[ -f "$logf" ]]; then
      echo "---- $logf ----" >> "$ALERT_FILE"
      tail -n 1000 "$logf" | grep -iE "$(IFS='|'; echo "${PATTERNS[*]}")" -n || true
    fi
  done
fi
if [[ -s "$ALERT_FILE" ]]; then
  echo "[$(date +%F %T)] Alerts found, saved to $ALERT_FILE"
else
  echo "[$(date +%F %T)] No critical alerts found in last $SINCE_MINUTES minutes"
  echo "No critical alerts found." >> "$ALERT_FILE"
fi
exit 0
