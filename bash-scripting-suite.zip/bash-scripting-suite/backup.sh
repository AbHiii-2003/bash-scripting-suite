#!/usr/bin/env bash
set -euo pipefail
BACKUP_BASE="${BACKUP_BASE:-/var/backups/maint_suite}"
RETENTION_DAYS="${RETENTION_DAYS:-7}"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
HOSTNAME="$(hostname -s)"
LOGFILE="${LOGFILE:-/var/log/maint_suite/backup.log}"
DEFAULT_DIRS=(/etc /home)
if [[ $# -ge 1 ]]; then
  DIRS=( "$@" )
else
  DIRS=( "${DEFAULT_DIRS[@]}" )
fi
mkdir -p "$BACKUP_BASE"
mkdir -p "$(dirname "$LOGFILE")"
echo "[$(date +%F %T)] Starting backup for: ${DIRS[*]}" | tee -a "$LOGFILE"
for src in "${DIRS[@]}"; do
  if [[ ! -e "$src" ]]; then
    echo "[$(date +%F %T)] WARNING: source not found: $src" | tee -a "$LOGFILE"
    continue
  fi
  name="$(basename "$src")"
  archive="${BACKUP_BASE}/${HOSTNAME}_${name}_${TIMESTAMP}.tar.gz"
  echo "[$(date +%F %T)] Archiving $src -> $archive" | tee -a "$LOGFILE"
  tar --exclude='/proc' --exclude='/sys' --exclude='/dev' --one-file-system -czf "$archive" -C "$(dirname "$src")" "$(basename "$src")"
  echo "[$(date +%F %T)] Finished $archive (size: $(du -h "$archive" | cut -f1))" | tee -a "$LOGFILE"
done
echo "[$(date +%F %T)] Cleaning backups older than $RETENTION_DAYS days" | tee -a "$LOGFILE"
find "$BACKUP_BASE" -type f -mtime +"$RETENTION_DAYS" -name '*.tar.gz' -print -exec rm -f {} \; | tee -a "$LOGFILE"
echo "[$(date +%F %T)] Backup finished" | tee -a "$LOGFILE"
exit 0
